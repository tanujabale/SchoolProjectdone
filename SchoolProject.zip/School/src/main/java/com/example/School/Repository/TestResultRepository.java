package com.example.School.Repository;

import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.School.entity.TestResult;
import java.util.List;
@Repository
public interface TestResultRepository extends JpaRepository<TestResult, Long> {
    List<TestResult> findAll();
}

