package com.example.School.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Services.StudentService;
import com.example.School.entity.Student;

import jakarta.transaction.Transactional;
@Controller
@Transactional
public class StudentRegeController {

	@Autowired
		private StudentService  studentservice;
	@GetMapping("/studentregister") 
	public String regiStudent(Model model) {
		
		model.addAttribute("student", new Student());
		
		return "StudentRegestration";
		
	}
	@PostMapping("/studentstatus")
	public String getstudentStatus(@Validated @ModelAttribute("student") Student student,BindingResult bindResult) {
		if(bindResult.hasErrors()) {
			return "StudentRegestration";
		}
		studentservice.saveStudent(student);
		return "redirect:/studentlogin";
	}

	}

		
		

