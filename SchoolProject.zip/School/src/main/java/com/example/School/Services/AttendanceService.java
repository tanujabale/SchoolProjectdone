package com.example.School.Services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.example.School.Repository.AttendanceRepository;
import com.example.School.Repository.StudentRepository;
import com.example.School.entity.Attendance;
import com.example.School.entity.Status;
import com.example.School.entity.Student;

import java.time.LocalDate;
import java.util.List;

@Service
public class AttendanceService {

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public void markAttendance(Long studentId, Status status) {
        Student student = studentRepository.findById(studentId).orElseThrow();
        Attendance attendance = new Attendance();
        attendance.setStudent(student);
        attendance.setStatus(status);
        attendanceRepository.save(attendance);
    }

    public List<Attendance> getAllAttendanceRecords() {
        return attendanceRepository.findAll();
    }
 
    public Attendance getAttendanceById(Long id) {
        return attendanceRepository.findById(id).orElseThrow();
    }

    public void updateAttendance(Long id, Status status) {
        Attendance attendance = attendanceRepository.findById(id).orElseThrow();
        attendance.setStatus(status);
        attendanceRepository.save(attendance);
    } 

    public void deleteAttendance(Long id) {
        attendanceRepository.deleteById(id);
    }
}
