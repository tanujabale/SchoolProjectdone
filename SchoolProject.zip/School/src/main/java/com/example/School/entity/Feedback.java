package com.example.School.entity;

public class Feedback {
    private String question;
    private String correctAnswer;
    private String userAnswer;
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getCorrectAnswer() {
		return correctAnswer;
	}
	public void setCorrectAnswer(String correctAnswer) {
		this.correctAnswer = correctAnswer;
	}
	public String getUserAnswer() {
		return userAnswer;
	}
	public void setUserAnswer(String userAnswer) {
		this.userAnswer = userAnswer;
	}
	@Override
	public String toString() {
		return "Feedback [question=" + question + ", correctAnswer=" + correctAnswer + ", userAnswer=" + userAnswer
				+ "]";
	}
	public Feedback(String question, String correctAnswer, String userAnswer) {
		super();
		this.question = question;
		this.correctAnswer = correctAnswer;
		this.userAnswer = userAnswer;
	}
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}
