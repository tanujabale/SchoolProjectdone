package com.example.School.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Services.FacultyService;
import com.example.School.Services.ResultService;
import com.example.School.entity.Faculty;
import com.example.School.entity.Result;

@Controller
public class AdminController {

    @Autowired
    private FacultyService facultyService;

    @PostMapping("/addFaculty")
    public String addFaculty(@ModelAttribute("faculty") Faculty faculty) {
        facultyService.addFaculty(faculty);
       return "redirect:/admindashboard"; 
    }
    @Autowired
    private ResultService resultservice;
    
    @GetMapping("/result")
    public String viewResult(Model model) {
        List<Result> resultList = resultservice.getAllResults();
        model.addAttribute("resultList", resultList);
        return "viewResult";  
    }
}
