package com.example.School.entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Entity;

@Entity
public class Result {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

	    private String name;
	    private int marathi;
	    private int english;
	    private int hindi;
	    private int mathematics;
	    private int history;
	    private int geography;
	    private int science;
	  

		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getMarathi() {
			return marathi;
		}
		public void setMarathi(int marathi) {
			this.marathi = marathi;
		}
		public int getEnglish() {
			return english;
		}
		public void setEnglish(int english) {
			this.english = english;
		}
		public int getHindi() {
			return hindi;
		}
		public void setHindi(int hindi) {
			this.hindi = hindi;
		}
		public int getMathematics() {
			return mathematics;
		}
		public void setMathematics(int mathematics) {
			this.mathematics = mathematics;
		}
		public int getHistory() {
			return history;
		}
		public void setHistory(int history) {
			this.history = history;
		}
		public int getGeography() {
			return geography;
		}
		public void setGeography(int geography) {
			this.geography = geography;
		}
		public int getScience() {
			return science;
		}
		public void setScience(int science) {
			this.science = science;
		}
		@Override
		public String toString() {
			return "Result [id=" + id + ", name=" + name + ", marathi=" + marathi + ", english=" + english + ", hindi="
					+ hindi + ", mathematics=" + mathematics + ", history=" + history + ", geography=" + geography
					+ ", science=" + science + "]";
		}
		public Result(Long id, String name, int marathi, int english, int hindi, int mathematics, int history,
				int geography, int science) {
			super();
			this.id = id;
			this.name = name;
			this.marathi = marathi;
			this.english = english;
			this.hindi = hindi;
			this.mathematics = mathematics;
			this.history = history;
			this.geography = geography;
			this.science = science;
		}
		public Result() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    
}
