package com.example.School.entity;
import jakarta.persistence.*;
@Entity
public class TestResult {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String studentName;
    private int score;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "TestResult [id=" + id + ", studentName=" + studentName + ", score=" + score + "]";
	}
	public TestResult(Long id, String studentName, int score) {
		super();
		this.id = id;
		this.studentName = studentName;
		this.score = score;
	}
	public TestResult() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
    
}
