package com.example.School.entity;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.example.School.Services.NotificationService;

@Component
public class SampleNotificationData {

    @Bean
    public CommandLineRunner initData(NotificationService notificationService) {
        return args -> {
  //          notificationService.createNotification("New fee payment reminder for the term", "Fee Reminder");
//            notificationService.createNotification("Upcoming Parent-Teacher Meeting on September 25", "Event");
//            notificationService.createNotification("Exam results for Class 10 are now available", "Results");
//            notificationService.createNotification("New academic calendar for 2024 has been released", "Academic Update");
//            notificationService.createNotification("Next term's syllabus has been uploaded", "Syllabus");
//            notificationService.createNotification("Science fair event scheduled for October 10", "Event");
//            notificationService.createNotification("Library book return deadline extended", "Library Update");
        };
    }
}
