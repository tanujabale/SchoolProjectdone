package com.example.School.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.example.School.Services.NotificationService;
import com.example.School.entity.Notification;


import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping
    public String getAllNotifications(Model model) {
        List<Notification> notifications = notificationService.getAllNotifications();
        model.addAttribute("notifications", notifications);
        return "notifications";
    }

    @GetMapping("/{id}")
    public String getNotificationById(@PathVariable Long id, Model model) {
        Optional<Notification> notification = notificationService.getNotificationById(id);
        if (notification.isPresent()) {
            model.addAttribute("notification", notification.get());
            return "notification-details";
        } else {
            return "error";
        }
    }

    @GetMapping("/new")
    public String showNewNotificationForm(Model model) {
        model.addAttribute("notification", new Notification());
        return "notification-form";
    }

    @PostMapping("/new")
    public String createNotification(@ModelAttribute Notification notification) {
        notificationService.createNotification(notification.getTitle(), notification.getMessage());
        return "redirect:/notifications";
    }
  

  
  
    @GetMapping("/delete/{id}")
    public String deleteNotification(@PathVariable Long id) {
        notificationService.deleteNotification(id);
        return "redirect:/notifications";
    }
}
