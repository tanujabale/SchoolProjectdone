package com.example.School.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Repository.TestResultRepository;
import com.example.School.entity.Question;
import com.example.School.entity.TestSubmission;
import com.example.School.entity.TestResult;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

//@Controller
//public class TestController {
//
//    private List<Question> questions;
//
//    @Autowired
//    private TestResultRepository testResultRepository;
//
//    // Initialize the questions
//    public TestController() {
//        questions = new ArrayList<>();
//        questions.add(new Question(1, "What is the highest common factor of the numbers 30 and 132?", "3", "6", "7", "9", "6"));
//        questions.add(new Question(2, "From the number 0 to the number 1000, the letter “A” appears only in?", "100", "3000", "1000", "1060", "1000"));
//        questions.add(new Question(3, "Which number is the equivalent to 3^(4)/3^(2)?", "-3", "9", "3", "6", "9"));
//        questions.add(new Question(4, "What is next in the following number series: 256, 289, 324, 361 . . . ?", "400", "200", "800", "500", "400"));
//        questions.add(new Question(5, "What is the value of Pi to four individual decimal places?", "3.1416", "1.1416", "2.1416", "4.1416", "3.1416"));
//        questions.add(new Question(6, "How many vertices are present on a cube?", "6", "8", "10", "14", "8"));
//        questions.add(new Question(7, "Which prime number is closest to 100?", "201", "110", "101", "229", "101"));
//        questions.add(new Question(8, "Which number is best represented in binary as 100?", "8", "4", "6", "2", "4"));
//        questions.add(new Question(9, "What is the cuberoot of 1331?", "11", "12", "13", "14", "11"));
//        questions.add(new Question(10, "What does 6 raised to the power of 0 equal?", "1", "6", "0", "36", "1"));
//    }
//
//    @GetMapping("/test")
//    public String showTest(Model model) {
//        model.addAttribute("questions", questions);
//        model.addAttribute("submission", new TestSubmission());
//        return "test";
//    }
//
//    @PostMapping("/submitTest")
//    public String submitTest(@ModelAttribute TestSubmission submission, Model model) {
//        int correctCount = 0;
//        int wrongCount = 0;
//        List<Question> wrongQuestions = new ArrayList<>();
//
//        for (Question question : questions) {
//            String selectedAnswer = submission.getAnswers().get(question.getId());
//            if (question.getCorrectAnswer().equals(selectedAnswer)) {
//                correctCount++;
//            } else {
//                wrongCount++;
//                wrongQuestions.add(question);
//            }
//        }
//
//        // Add student name to the model
//        model.addAttribute("studentName", submission.getStudentName());
//        model.addAttribute("totalQuestions", questions.size());
//        model.addAttribute("correctCount", correctCount);
//        model.addAttribute("wrongCount", wrongCount);
//        model.addAttribute("wrongQuestions", wrongQuestions);
//        model.addAttribute("score", (correctCount * 100) / questions.size());
//
//        return "result"; // this should be the Thymeleaf template displaying the result
//    }
//
//
//    @GetMapping("/testresult")
//    public String viewTestResults(Model model) {
//        // Fetch all test results to display to the faculty
//        List<TestResult> testResults = testResultRepository.findAll();
//        model.addAttribute("testResults", testResults);
//        return "testresult"; // The Thymeleaf template for displaying results
//    }
//    
//}


@Controller
public class TestController {

    private List<Question> questions;

    @Autowired
    private TestResultRepository testResultRepository;

    // Initialize the questions
    public TestController() {
        questions = new ArrayList<>();
        questions.add(new Question(1, "What is the highest common factor of the numbers 30 and 132?", "3", "6", "7", "9", "6"));
        questions.add(new Question(2, "From the number 0 to the number 1000, the letter “A” appears only in?", "100", "3000", "1000", "1060", "1000"));
        questions.add(new Question(3, "Which number is the equivalent to 3^(4)/3^(2)?", "-3", "9", "3", "6", "9"));
        questions.add(new Question(4, "What is next in the following number series: 256, 289, 324, 361 . . . ?", "400", "200", "800", "500", "400"));
        questions.add(new Question(5, "What is the value of Pi to four individual decimal places?", "3.1416", "1.1416", "2.1416", "4.1416", "3.1416"));
        questions.add(new Question(6, "How many vertices are present on a cube?", "6", "8", "10", "14", "8"));
        questions.add(new Question(7, "Which prime number is closest to 100?", "201", "110", "101", "229", "101"));
        questions.add(new Question(8, "Which number is best represented in binary as 100?", "8", "4", "6", "2", "4"));
        questions.add(new Question(9, "What is the cuberoot of 1331?", "11", "12", "13", "14", "11"));
        questions.add(new Question(10, "What does 6 raised to the power of 0 equal?", "1", "6", "0", "36", "1"));
    }

    @GetMapping("/test")
    public String showTest(Model model) {
        model.addAttribute("questions", questions);
        model.addAttribute("submission", new TestSubmission());
        return "test";
    }

    @PostMapping("/submitTest")
    public String submitTest(@ModelAttribute TestSubmission submission, Model model) {
        int correctCount = 0;
        int wrongCount = 0;
        List<Question> wrongQuestions = new ArrayList<>();

        for (Question question : questions) {
            String selectedAnswer = submission.getAnswers().get(question.getId());
            if (question.getCorrectAnswer().equals(selectedAnswer)) {
                correctCount++;
            } else {
                wrongCount++;
                wrongQuestions.add(question);
            }
        }

        // Calculate the score
        int totalQuestions = questions.size();
        int score = (correctCount * 100) / totalQuestions;

        // Save the result in the repository (add studentName to the submission form)
        TestResult testResult = new TestResult();
        testResult.setStudentName(submission.getStudentName()); // Assuming TestSubmission has studentName field
        testResult.setScore(score);
        testResultRepository.save(testResult); // Save the result to the database

        // Send data back to the result page
        model.addAttribute("totalQuestions", totalQuestions);
        model.addAttribute("correctCount", correctCount);
        model.addAttribute("wrongCount", wrongCount);
        model.addAttribute("wrongQuestions", wrongQuestions);
        model.addAttribute("score", score);

        return "result"; // The result page for the student
    }

    @GetMapping("/testresult")
    public String viewTestResults(Model model) {
        // Fetch all test results to display to the faculty
        List<TestResult> testResults = testResultRepository.findAll();
        model.addAttribute("testResults", testResults);
        return "testresult"; // The Thymeleaf template for displaying results
    }
}
