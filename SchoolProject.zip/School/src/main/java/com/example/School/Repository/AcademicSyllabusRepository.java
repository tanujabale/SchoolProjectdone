package com.example.School.Repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.example.School.entity.Syllabus;

public interface AcademicSyllabusRepository extends JpaRepository<Syllabus, Long> {
}

 