package com.example.School.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.School.Services.FileStorageService;
import com.example.School.Services.ResultService;
import com.example.School.Services.StudentService;
import com.example.School.entity.Faculty;
import com.example.School.entity.Result;
import com.example.School.entity.Student;

@Controller
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/students")
    public String viewStudentList(Model model) {
        model.addAttribute("students", studentService.getAllStudents());
        return "student-list";
    }

    @GetMapping("/addStudent")
    public String addStudentForm(Model model) {
        model.addAttribute("student", new Student());
        return "add-student";
    }

    @PostMapping("/saveStudent")
    public String saveStudent(@ModelAttribute("student") Student student) {
        studentService.saveStudent(student);
        return "redirect:/students";
    }

    @GetMapping("/editStudent/{id}")
    public String editStudentForm(@PathVariable Long id, Model model) {
        Student student = studentService.getStudentById(id);
        model.addAttribute("student", student);
        return "edit-student";
    }

    @PostMapping("/updateStudent/{id}")
    public String updateStudent(@PathVariable Long id, @ModelAttribute("student") Student student) {
        Student existingStudent = studentService.getStudentById(id);
        existingStudent.setFirstName(student.getFirstName());
        existingStudent.setLastName(student.getLastName());
        existingStudent.setAge(student.getAge());
        existingStudent.setGender(student.getGender());
        existingStudent.setStudentClass(student.getStudentClass());
        existingStudent.setEmail(student.getEmail());
        existingStudent.setAddress(student.getAddress());

        studentService.saveStudent(existingStudent);
        return "redirect:/students";
    }

    @GetMapping("/deleteStudent/{id}")
    public String deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return "redirect:/students";
    }
    
    @Autowired
    private StudentService studentservice;

    @GetMapping("/viewStudent")
    public String viewStudent(Model model) {
        List<Student> studentList = studentservice.getAllStudents();
        model.addAttribute("studentList", studentList);
        return "viewStudent";  
    }
    @Autowired
   private FileStorageService fileStorageService;

    @GetMapping("/studyMaterial")
    public String viewStudyMaterial(Model model) {
        // Retrieve the list of uploaded study materials from the file storage service
        List<String> files = fileStorageService.listAllFiles(); // Assumes files are stored centrally
        model.addAttribute("files", files);
        return "study-material"; // Return the view to display study materials
    }
    @GetMapping("/files/download/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> downloadFile(@PathVariable String filename) {
        Resource file = fileStorageService.loadFileAsResource(filename);
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + file.getFilename() + "\"")
                .body(file);
    }
    @GetMapping("/search")
    public String searchFiles(@RequestParam("query") String query, Model model) {
        // Assuming 'files' is a List of file names or paths
        List<String> files = fileStorageService.getAllFiles();
        
        // Filter files based on the query
        List<String> filteredFiles = files.stream()
            .filter(file -> file.toLowerCase().contains(query.toLowerCase()))
            .collect(Collectors.toList());

        model.addAttribute("files", filteredFiles);
        return "study-material";
    }
}

