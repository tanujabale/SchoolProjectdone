package com.example.School.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.Repository.FacultyRepository;
import com.example.School.entity.Faculty;

import java.util.List;
import java.util.Optional;

@Service
public class FacultyService {

    @Autowired
    private FacultyRepository facultyRepository;

    public List<Faculty> getAllFaculty() {
        List<Faculty> facultyList = facultyRepository.findAll();
        System.out.println("Faculty List: " + facultyList); // Debugging
        return facultyList;
    }


    // Fetch a specific faculty member by ID
    public Optional<Faculty> getFacultyById(Long id) {
        return facultyRepository.findById(id);
    }

    // Add a new faculty member
    public Faculty addFaculty(Faculty faculty) {
        return facultyRepository.save(faculty);
    }

    // Update an existing faculty member
    public Faculty updateFaculty(Long id, Faculty updatedFaculty) {
        return facultyRepository.findById(id)
                .map(faculty -> {
                    faculty.setFirstName(updatedFaculty.getFirstName());
                    faculty.setLastName(updatedFaculty.getLastName());
                    faculty.setEmail(updatedFaculty.getEmail());
                    faculty.setGender(updatedFaculty.getGender());
                    faculty.setPhoneNo(updatedFaculty.getPhoneNo());
                    faculty.setSubject(updatedFaculty.getSubject());
                    faculty.setUsername(updatedFaculty.getUsername());
                    faculty.setPassword(updatedFaculty.getPassword());

                    return facultyRepository.save(faculty);
                })
                .orElseThrow(() -> new IllegalArgumentException("Invalid faculty ID: " + id));
    }

    // Delete a faculty member by ID
    public void deleteFaculty(Long id) {
        facultyRepository.deleteById(id);
    }
    
    public Faculty saveFaculty(Faculty faculty) {
		return facultyRepository.save(faculty);
}
    
    public List<Faculty> FacultyList() {
		List<Faculty> find= facultyRepository.findAll();
		return find;
	}
    
    
}

