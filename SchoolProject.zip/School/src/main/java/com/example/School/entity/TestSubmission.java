package com.example.School.entity;

//
//import java.util.HashMap;
//import java.util.Map;
//
//public class TestSubmission {
//    private Map<Integer, String> answers = new HashMap<>();
//
//    public Map<Integer, String> getAnswers() {
//        return answers;
//    }
//
//    public void setAnswers(Map<Integer, String> answers) {
//        this.answers = answers;
//    }
////
////	public String getStudentName() {
////		// TODO Auto-generated method stub
////		return null;
////	}
//}

import java.util.Map;

public class TestSubmission {

    private String studentName; // The student's name
    private Map<Integer, String> answers; // A map of question IDs and selected answers

    // Default constructor
    public TestSubmission() {}

    // Getters and Setters
    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Map<Integer, String> getAnswers() {
        return answers;
    }

    public void setAnswers(Map<Integer, String> answers) {
        this.answers = answers;
    }
}
