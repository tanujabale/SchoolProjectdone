package com.example.School.entity;

import java.util.List;

public class TestForm {
    private List<String> answers;  // List of answers submitted by the user
    private String studentName;
	public List<String> getAnswers() {
		return answers;
	}

	public void setAnswers(List<String> answers) {
		this.answers = answers;
	}
	

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public TestForm(List<String> answers) {
		super();
		this.answers = answers;
	}

	@Override
	public String toString() {
		return "TestForm [answers=" + answers + "]";
	}

	public TestForm() {
		super();
		// TODO Auto-generated constructor stub
	}
    

}
