package com.example.School.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.School.Services.BookService;
import com.example.School.entity.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/library")
public class LibraryController {

    @Autowired
    private BookService libraryService;

    // Display the library page with list of books
    @GetMapping
    public String showLibrary(Model model) {
        List<Book> books = libraryService.getAllBooks();
        model.addAttribute("books", books);
        model.addAttribute("book", new Book()); // For the addBook form
        return "library"; // Thymeleaf template name
    }

    // Add a new book
    @PostMapping("/addBook")
    public String addBook(@ModelAttribute Book book) {
        libraryService.addBook(book);
        return "redirect:/library"; // Redirect to the library page after adding the book
    }

    // Delete a book by its ID
    @PostMapping("/deleteBook/{id}")
    public String deleteBook(@PathVariable Long id) {
        libraryService.deleteBookById(id);
        return "redirect:/library"; // Redirect to the library page after deleting the book
    }
}
