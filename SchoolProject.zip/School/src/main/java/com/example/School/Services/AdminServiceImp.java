package com.example.School.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.School.Repository.AdminRepo;
import com.example.School.entity.Admin;

@Service
public class AdminServiceImp implements AdminService{

	@Autowired
	private AdminRepo adminRepo;

	
	public Admin saveAdmin(Admin admin) {
				return adminRepo.save(admin);
	}

	@Override
	public List<Admin> adminList() {
		List<Admin> find= adminRepo.findAll();
		return find;
	}


	}

	
	
	
	


